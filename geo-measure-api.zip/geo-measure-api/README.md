# Geospatial File Measurement API

A FastAPI service that accepts a **Shapefile (`.zip`)** or **KML** file, extracts every feature
(geometry, CRS, attributes) and returns **area / length measurements in metres** — computed in a
properly selected projected CRS, never in raw latitude/longitude degrees.

## Setup

Requires Python 3.10+.

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt

uvicorn app.main:app --reload          # http://localhost:8000
pytest                                  # run the test-suite
```

Interactive docs (Swagger UI): <http://localhost:8000/docs>

Docker alternative:

```bash
docker build -t geo-measure-api . && docker run -p 8000:8000 geo-measure-api
```

Configuration (environment variables, all optional):

| Variable | Default | Meaning |
|---|---|---|
| `GEO_DB_PATH` | `data/geo.db` | SQLite file |
| `GEO_MAX_UPLOAD_MB` | `50` | Max upload size |
| `GEO_MAX_UNCOMPRESSED_MB` | `300` | Max total size of a zip's contents (zip-bomb guard) |
| `GEO_MAX_FEATURES` | `200000` | Max features per file |

Sample files are in `sample_data/` (regenerate with `python scripts/make_samples.py`).

## API

### `POST /api/files/` — upload & process
Multipart form field `file` (`.kml` or `.zip` containing one Shapefile).

```bash
curl -X POST http://localhost:8000/api/files/ -F "file=@sample_data/survey.kml"
```
```json
{
  "id": "f374589a988c4a1aae30605a69c52f38",
  "filename": "survey.kml",
  "feature_count": 4,
  "crs": "EPSG:4326",
  "status": "COMPLETED",
  "error": null,
  "created_at": "2026-10-07T15:00:29.685548+00:00"
}
```

| Code | When |
|---|---|
| 201 | Processed |
| 413 | Over the upload limit |
| 415 | Extension is not `.zip` / `.kml` |
| 422 | Unreadable file, no `.shp` in zip, Shapefile without CRS, empty file… (a `FAILED` record is stored; body is `{"detail": "...", "id": "..."}`) |

### `GET /api/files/{id}/` — file information
Returns the same object as above. `status` is `PROCESSING`, `COMPLETED` or `FAILED` (with `error`). 404 if unknown.

### `GET /api/files/{id}/measurements/` — measurements
Query params: `limit` (1–1000, default 100), `offset`, `geometry_type` (e.g. `Polygon`).
Returns 409 if the file is not `COMPLETED`.

```json
{
  "file_id": "f374589a…",
  "crs": "EPSG:4326",
  "summary": {
    "feature_count_by_geometry_type": {"Polygon": 1, "LineString": 1, "Point": 1, "GeometryCollection": 1},
    "feature_count_by_status": {"MEASURED": 2, "NOT_APPLICABLE": 1, "UNSUPPORTED": 1},
    "total_area_sq_m": 1210604.1373,
    "total_area_hectares": 121.060414,
    "total_length_m": 5300.0004
  },
  "page": {"total": 4, "limit": 100, "offset": 0},
  "measurements": [
    {"feature_index": 0, "geometry_type": "Polygon",
     "measurement": {"status": "MEASURED", "area_sq_m": 1210604.1373, "area_hectares": 121.060414,
                     "perimeter_m": 4401.1699, "length_m": null, "projected_crs": "EPSG:32644", "message": null}},
    {"feature_index": 1, "geometry_type": "LineString",
     "measurement": {"status": "MEASURED", "length_m": 5300.0004, "projected_crs": "EPSG:32644", "...": "..."}},
    {"feature_index": 2, "geometry_type": "Point",
     "measurement": {"status": "NOT_APPLICABLE", "message": "Points have no area or length", "...": "..."}},
    {"feature_index": 3, "geometry_type": "GeometryCollection",
     "measurement": {"status": "UNSUPPORTED", "message": "Measurement not supported for GeometryCollection", "...": "..."}}
  ]
}
```

Per-feature `status`: `MEASURED`, `NOT_APPLICABLE` (points), `UNSUPPORTED` (e.g. GeometryCollection), `INVALID` (null/empty geometry or projection failure).
The summary is aggregated over the **whole file**, not just the returned page.

### `GET /api/files/{id}/features/` *(extra)* — geometry & attributes
Same pagination/filter params. Each feature has `feature_index`, `geometry_type`, `geometry` (GeoJSON in the file's **original CRS**), `is_valid`, `properties`, and `measurement`.

## Architecture

```
app/
├── main.py              # app factory, error handler, /health
├── config.py            # env-based settings
├── errors.py            # typed errors -> HTTP status codes
├── schemas.py           # Pydantic response models
├── repository.py        # SQLite persistence
├── api/routes.py        # HTTP layer only (validation, status codes)
└── services/
    ├── readers.py       # .kml / .zip(shapefile) -> GeoDataFrame + CRS
    ├── processor.py     # orchestration: read -> per-feature extract + measure
    ├── measurements.py  # pure measurement logic
    └── crs.py           # CRS description, UTM zone selection, transformer cache
```

**File-processing flow**
1. Route validates the extension and streams the upload to a temp file, aborting past the size limit.
2. A `files` row is created (`PROCESSING`).
3. `readers` loads the data: KML → every KML Folder/layer merged; zip → only whitelisted Shapefile parts are extracted, with names flattened (no zip-slip) and an uncompressed-size cap.
4. `processor` walks each feature: index, geometry type, GeoJSON geometry (Z dropped), JSON-safe properties (NaN/NaT/numpy types normalised), validity flag, measurement.
5. All features are stored in one transaction and the file becomes `COMPLETED`. Any expected failure marks it `FAILED` with a message.

**Measurement flow** (`measurements.measure_geometry`) — never raises for bad input:
Empty/null → `INVALID` · Point/MultiPoint → `NOT_APPLICABLE` · other types → `UNSUPPORTED` ·
Polygon/MultiPolygon → area (m², hectares) + perimeter · LineString/MultiLineString → length (m).

**CRS handling**
* KML: always WGS84 (EPSG:4326) by specification.
* Shapefile: CRS read from `.prj`. If absent, the file is **rejected** (guessing a CRS gives silently wrong numbers).
* *Geographic CRS* → the UTM zone of the feature's representative point is chosen (EPSG:326xx north / 327xx south; UPS beyond 84°N/80°S), the geometry is reprojected there, then measured in metres.
* *Projected CRS* → measured directly in that CRS, scaled by the CRS's unit factor, so files in feet are correct too.
* Every measurement reports the `projected_crs` that was used. Transformers are cached.

## Design decisions

| Decision | Why / alternatives considered |
|---|---|
| **FastAPI** over Django+DRF | Lightweight, typed, automatic OpenAPI docs; no ORM/admin needed for this scope. |
| **GeoPandas + pyogrio (GDAL)** for reading | One code path for both formats, handles encodings and KML folders. Fiona is the older alternative; pyogrio is faster and has bundled wheels. |
| **Per-feature UTM** vs one CRS per file | Files can span zones; choosing per feature bounds distortion to <~0.1–0.4%. Trade-off: per-feature work, mitigated by transformer caching. |
| **UTM vs equal-area / geodesic** | UTM is simple, conformal, explainable. A purely geodesic approach (`pyproj.Geod`) is exact but only the *tests* use it (as ground truth) because the spec asks for projected measurement. A custom Lambert Azimuthal Equal-Area per feature would be better for very large areas. |
| **Synchronous processing** | Simple and deterministic; fine up to the configured limits. The `status` field and repository already model an async lifecycle (see future scope). |
| **Measure at upload, store results** | Reads are cheap and consistent; files aren't kept on disk after processing. Alternative: store raw file and compute lazily. |
| **SQLite (stdlib)** | Zero-setup for reviewers. Repository is isolated so Postgres/PostGIS can replace it. |
| **Reject Shapefile with no CRS** | Correctness over convenience. |
| **Unsupported ≠ error** | Each feature carries its own status; one odd feature never fails the file. |
| **Security** | Size limit, extension allow-list, zip-bomb cap, zip-slip safe extraction, no user-controlled paths. |

## Testing
`pytest` — 26 tests: UTM zone selection; polygon/line results checked against geodesic ground truth
(`pyproj.Geod`) at several latitudes; feet-based projected CRS; same data in EPSG:4326 vs EPSG:32644
gives the same area; KML + Shapefile end-to-end; pagination; and error paths (bad extension, corrupt
KML, zip without `.shp`, missing CRS, empty file, oversize upload, zip-slip).

## Learnings
* A Shapefile can hold only one geometry type; KML mixes types freely and exposes Folders as GDAL layers.
* The "right" projection depends on the question: UTM is conformal (good for lengths/angles), equal-area projections are better for area. UTM error is small at feature scale but grows for huge features.
* Silent assumptions (missing `.prj`, KML `MultiGeometry`) are where geospatial pipelines usually go wrong, so these are explicit statuses/errors rather than guesses.
* Validating numbers against an independent geodesic calculation catches degree-vs-metre mistakes immediately.

## Future scope
* Background processing (Celery/RQ) with polling or webhooks for large files; chunked/streamed reading.
* PostgreSQL + PostGIS storage and spatial queries (bbox filters, `ST_Area(geography)`).
* `.kmz`, GeoJSON, GeoPackage support; multi-Shapefile zips.
* Per-feature equal-area / geodesic method selectable via a query parameter; antimeridian and polar edge cases.
* Handle `GeometryCollection` by measuring its members; geometry repair (`make_valid`) option.
* Auth, rate limiting, file retention policy, Docker Compose, CI (GitHub Actions) and a map-preview endpoint.
