"""Generate sample_data/ files (KML + zipped Shapefile) around Tiruchirappalli."""
from pathlib import Path
import shutil
import tempfile

import geopandas as gpd
from shapely.geometry import LineString, Point, Polygon

OUT = Path(__file__).resolve().parent.parent / "sample_data"
OUT.mkdir(exist_ok=True)

KML = """<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2"><Document>
  <Folder><name>Survey</name>
    <Placemark><name>Plot A</name><description>Farm plot</description>
      <Polygon><outerBoundaryIs><LinearRing><coordinates>
        78.6800,10.8000,0 78.6900,10.8000,0 78.6900,10.8100,0 78.6800,10.8100,0 78.6800,10.8000,0
      </coordinates></LinearRing></outerBoundaryIs></Polygon></Placemark>
    <Placemark><name>Road 1</name>
      <LineString><coordinates>78.68,10.80,0 78.70,10.82,0 78.72,10.82,0</coordinates></LineString></Placemark>
    <Placemark><name>Well</name><Point><coordinates>78.685,10.805,0</coordinates></Point></Placemark>
    <Placemark><name>Mixed</name><MultiGeometry>
      <Point><coordinates>78.69,10.81,0</coordinates></Point>
      <LineString><coordinates>78.69,10.81,0 78.70,10.82,0</coordinates></LineString>
    </MultiGeometry></Placemark>
  </Folder>
</Document></kml>
"""
(OUT / "survey.kml").write_text(KML)

# A Shapefile holds a single geometry type, so write polygons and lines separately.
polys = gpd.GeoDataFrame(
    {"name": ["Plot A", "Plot B"], "owner": ["Kumar", "Devi"]},
    geometry=[
        Polygon([(78.68, 10.80), (78.69, 10.80), (78.69, 10.81), (78.68, 10.81)]),
        Polygon([(78.70, 10.80), (78.71, 10.80), (78.71, 10.82), (78.70, 10.82)]),
    ],
    crs="EPSG:4326",
)
lines = gpd.GeoDataFrame(
    {"name": ["Road 1"]},
    geometry=[LineString([(78.68, 10.80), (78.70, 10.82), (78.72, 10.82)])],
    crs="EPSG:4326",
)
for name, gdf in {"plots": polys, "roads": lines}.items():
    with tempfile.TemporaryDirectory() as tmp:
        gdf.to_file(Path(tmp) / f"{name}.shp")
        shutil.make_archive(str(OUT / f"{name}_shapefile"), "zip", tmp)
print("Sample files written to", OUT)
