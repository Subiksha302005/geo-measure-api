class GeoServiceError(Exception):
    """Base class for expected, user-facing errors."""
    status_code = 400


class UnsupportedFileType(GeoServiceError):
    status_code = 415


class FileTooLarge(GeoServiceError):
    status_code = 413


class ProcessingError(GeoServiceError):
    """File was received but its content could not be processed."""
    status_code = 422
