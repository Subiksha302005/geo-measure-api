"""Orchestrates: read file -> extract features -> measure each one."""
from __future__ import annotations

import datetime as dt
import math
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from shapely import force_2d, to_geojson
import json

from ..errors import ProcessingError
from .crs import crs_to_string
from .measurements import measure_geometry
from .readers import load_file


@dataclass
class ProcessedFile:
    crs: str
    features: list[dict]  # one dict per feature, ready for storage


def process_file(path: Path, original_name: str, max_uncompressed: int, max_features: int) -> ProcessedFile:
    with tempfile.TemporaryDirectory(prefix="geo_") as tmp:
        loaded = load_file(path, original_name, Path(tmp), max_uncompressed)

    gdf = loaded.gdf
    if len(gdf) > max_features:
        raise ProcessingError(f"Too many features ({len(gdf)}); limit is {max_features}")

    geom_col = gdf.geometry.name
    prop_cols = [c for c in gdf.columns if c != geom_col]

    features: list[dict] = []
    for idx, (row, geom) in enumerate(zip(gdf[prop_cols].to_dict("records"), gdf.geometry)):
        geom_json = None
        if geom is not None and not geom.is_empty:
            # Geometry is returned in the file's original CRS (Z dropped for consistency).
            geom_json = json.loads(to_geojson(force_2d(geom)))
        features.append(
            {
                "feature_index": idx,
                "geometry_type": geom.geom_type if geom is not None else None,
                "geometry": geom_json,
                "is_valid": bool(geom.is_valid) if geom is not None and not geom.is_empty else False,
                "properties": {str(k): _json_safe(v) for k, v in row.items()},
                "measurement": measure_geometry(geom, loaded.crs).to_dict(),
            }
        )
    return ProcessedFile(crs=crs_to_string(loaded.crs) or "UNKNOWN", features=features)


def _json_safe(value: Any) -> Any:
    """Convert pandas/numpy scalars into plain JSON-serialisable values."""
    if value is None or value is pd.NaT:
        return None
    if isinstance(value, (pd.Timestamp, dt.datetime, dt.date)):
        return value.isoformat()
    if isinstance(value, np.generic):
        value = value.item()
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return value
