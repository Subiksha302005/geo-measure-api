"""CRS helpers: describing CRSs and choosing a projected CRS for measuring."""
from __future__ import annotations

from functools import lru_cache

from pyproj import CRS, Transformer

# UTM is only defined between 80°S and 84°N; beyond that we use UPS.
_UPS_NORTH = 32661
_UPS_SOUTH = 32761


def crs_to_string(crs: CRS | None) -> str | None:
    """'EPSG:4326' when an authority code exists, otherwise the CRS name."""
    if crs is None:
        return None
    auth = crs.to_authority()
    if auth:
        return f"{auth[0]}:{auth[1]}"
    return crs.name


def utm_epsg_for(lon: float, lat: float) -> int:
    """EPSG code of the UTM zone (or UPS cap) containing lon/lat."""
    if lat > 84:
        return _UPS_NORTH
    if lat < -80:
        return _UPS_SOUTH
    zone = min(max(int((lon + 180) // 6) + 1, 1), 60)
    return (32600 if lat >= 0 else 32700) + zone


@lru_cache(maxsize=256)
def get_transformer(src_wkt: str, dst_epsg: int) -> Transformer:
    return Transformer.from_crs(CRS.from_wkt(src_wkt), CRS.from_epsg(dst_epsg), always_xy=True)


def linear_unit_factor(crs: CRS) -> float:
    """Metres per CRS axis unit (1.0 for metre-based projected CRSs)."""
    try:
        return float(crs.axis_info[0].unit_conversion_factor)
    except (IndexError, AttributeError):
        return 1.0
