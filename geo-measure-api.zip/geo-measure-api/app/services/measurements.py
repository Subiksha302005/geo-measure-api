"""Measurement calculation.

Strategy
--------
* Geographic CRS (degrees, e.g. EPSG:4326): pick the UTM zone containing the
  feature's representative point, reproject the geometry there, then measure
  with planar maths in metres. Picking the zone *per feature* keeps distortion
  small even if one file spans several zones.
* Projected CRS: measure directly in the file's CRS, scaled to metres using the
  CRS's unit (so US-survey-feet files work too).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from pyproj import CRS
import numpy as np
import shapely
from shapely import force_2d
from shapely.geometry.base import BaseGeometry

from .crs import crs_to_string, get_transformer, linear_unit_factor, utm_epsg_for

AREA_TYPES = {"Polygon", "MultiPolygon"}
LENGTH_TYPES = {"LineString", "MultiLineString", "LinearRing"}
POINT_TYPES = {"Point", "MultiPoint"}

MEASURED = "MEASURED"
NOT_APPLICABLE = "NOT_APPLICABLE"
UNSUPPORTED = "UNSUPPORTED"
INVALID = "INVALID"

SQM_PER_HECTARE = 10_000.0


@dataclass
class Measurement:
    status: str
    message: Optional[str] = None
    area_sq_m: Optional[float] = None
    area_hectares: Optional[float] = None
    perimeter_m: Optional[float] = None
    length_m: Optional[float] = None
    projected_crs: Optional[str] = None

    def to_dict(self) -> dict:
        return self.__dict__.copy()


def measure_geometry(geom: BaseGeometry | None, src_crs: CRS) -> Measurement:
    """Measure one geometry. Never raises for bad/unsupported input."""
    if geom is None or geom.is_empty:
        return Measurement(INVALID, "Geometry is missing or empty")

    gtype = geom.geom_type
    if gtype in POINT_TYPES:
        return Measurement(NOT_APPLICABLE, "Points have no area or length")
    if gtype not in AREA_TYPES | LENGTH_TYPES:
        return Measurement(UNSUPPORTED, f"Measurement not supported for {gtype}")

    try:
        planar, planar_crs, factor = _to_planar(force_2d(geom), src_crs)
    except Exception as exc:  # reprojection failures must not break the file
        return Measurement(INVALID, f"Could not project geometry: {exc}")

    projected_name = crs_to_string(planar_crs)
    if gtype in AREA_TYPES:
        area = planar.area * factor**2
        return Measurement(
            MEASURED,
            area_sq_m=round(area, 4),
            area_hectares=round(area / SQM_PER_HECTARE, 6),
            perimeter_m=round(planar.length * factor, 4),
            projected_crs=projected_name,
        )
    return Measurement(
        MEASURED, length_m=round(planar.length * factor, 4), projected_crs=projected_name
    )


def _to_planar(geom: BaseGeometry, src_crs: CRS) -> tuple[BaseGeometry, CRS, float]:
    """Return (planar geometry, its CRS, metres-per-unit)."""
    if src_crs.is_projected:
        return geom, src_crs, linear_unit_factor(src_crs)

    pt = geom.representative_point()
    epsg = utm_epsg_for(pt.x, pt.y)
    transformer = get_transformer(src_crs.to_wkt(), epsg)
    def _project(coords: np.ndarray) -> np.ndarray:
        x, y = transformer.transform(coords[:, 0], coords[:, 1])
        return np.column_stack([x, y])

    return shapely.transform(geom, _project), CRS.from_epsg(epsg), 1.0
