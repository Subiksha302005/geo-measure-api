"""Readers turning an uploaded file into a GeoDataFrame + CRS.

Supported inputs: ``.zip`` (containing a Shapefile) and ``.kml``.
"""
from __future__ import annotations

import shutil
import zipfile
from dataclasses import dataclass
from pathlib import Path

import geopandas as gpd
import pandas as pd
import pyogrio
from pyproj import CRS

from ..errors import ProcessingError, UnsupportedFileType

SHAPEFILE_PARTS = {".shp", ".shx", ".dbf", ".prj", ".cpg"}
WGS84 = CRS.from_epsg(4326)


@dataclass
class LoadedData:
    gdf: gpd.GeoDataFrame
    crs: CRS
    crs_assumed: bool = False


def load_file(path: Path, original_name: str, workdir: Path, max_uncompressed: int) -> LoadedData:
    ext = Path(original_name).suffix.lower()
    if ext == ".kml":
        return _read_kml(path)
    if ext == ".zip":
        return _read_shapefile_zip(path, workdir, max_uncompressed)
    raise UnsupportedFileType("Unsupported file type. Upload a .zip (Shapefile) or .kml file.")


def _read_kml(path: Path) -> LoadedData:
    """KML Folders are exposed by GDAL as layers, so read and merge them all."""
    try:
        layers = [name for name, _ in pyogrio.list_layers(path)]
        frames = []
        for layer in layers:
            df = pyogrio.read_dataframe(path, layer=layer)
            if df.empty:
                continue
            df["layer"] = layer
            frames.append(df)
    except Exception as exc:
        raise ProcessingError(f"Could not read KML: {exc}") from exc

    if not frames:
        raise ProcessingError("KML contains no features")
    gdf = gpd.GeoDataFrame(pd.concat(frames, ignore_index=True), geometry="geometry")
    # The KML specification fixes coordinates to WGS84 lon/lat.
    gdf = gdf.set_crs(WGS84, allow_override=True)
    return LoadedData(gdf, WGS84)


def _read_shapefile_zip(path: Path, workdir: Path, max_uncompressed: int) -> LoadedData:
    try:
        archive = zipfile.ZipFile(path)
    except zipfile.BadZipFile as exc:
        raise ProcessingError("File is not a valid zip archive") from exc

    with archive:
        members = [m for m in archive.infolist() if not m.is_dir()]
        if sum(m.file_size for m in members) > max_uncompressed:
            raise ProcessingError("Archive is too large when uncompressed")

        extract_dir = workdir / "shp"
        extract_dir.mkdir()
        shp_names: list[str] = []
        for m in members:
            # Flatten the name: ignores any path components, so zip-slip is impossible.
            name = Path(m.filename).name
            if name.startswith(".") or Path(name).suffix.lower() not in SHAPEFILE_PARTS:
                continue
            with archive.open(m) as src, open(extract_dir / name, "wb") as dst:
                shutil.copyfileobj(src, dst)
            if name.lower().endswith(".shp"):
                shp_names.append(name)

    if not shp_names:
        raise ProcessingError("Zip does not contain a .shp file")
    if len(shp_names) > 1:
        raise ProcessingError("Zip contains more than one Shapefile; upload them separately")

    shp = extract_dir / shp_names[0]
    try:
        gdf = pyogrio.read_dataframe(shp)
    except Exception as exc:
        raise ProcessingError(f"Could not read Shapefile: {exc}") from exc

    if gdf.crs is None:
        raise ProcessingError(
            "Shapefile has no CRS (.prj missing or unreadable); "
            "measurements would be unreliable, so the file was rejected"
        )
    return LoadedData(gdf, CRS.from_user_input(gdf.crs))
