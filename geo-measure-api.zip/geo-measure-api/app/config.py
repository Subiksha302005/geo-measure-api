"""Runtime configuration, read from environment variables."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    db_path: Path
    max_upload_bytes: int
    max_uncompressed_bytes: int
    max_features: int

    @classmethod
    def from_env(cls) -> "Settings":
        mb = 1024 * 1024
        return cls(
            db_path=Path(os.getenv("GEO_DB_PATH", "data/geo.db")),
            max_upload_bytes=int(os.getenv("GEO_MAX_UPLOAD_MB", "50")) * mb,
            max_uncompressed_bytes=int(os.getenv("GEO_MAX_UNCOMPRESSED_MB", "300")) * mb,
            max_features=int(os.getenv("GEO_MAX_FEATURES", "200000")),
        )
