from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel


class FileInfo(BaseModel):
    id: str
    filename: str
    feature_count: int
    crs: Optional[str] = None
    status: str  # PROCESSING | COMPLETED | FAILED
    error: Optional[str] = None
    created_at: str


class MeasurementOut(BaseModel):
    status: str  # MEASURED | NOT_APPLICABLE | UNSUPPORTED | INVALID
    message: Optional[str] = None
    area_sq_m: Optional[float] = None
    area_hectares: Optional[float] = None
    perimeter_m: Optional[float] = None
    length_m: Optional[float] = None
    projected_crs: Optional[str] = None


class FeatureMeasurement(BaseModel):
    feature_index: int
    geometry_type: Optional[str]
    measurement: MeasurementOut


class Feature(BaseModel):
    feature_index: int
    geometry_type: Optional[str]
    geometry: Optional[dict[str, Any]]
    is_valid: bool
    properties: dict[str, Any]
    measurement: MeasurementOut


class Summary(BaseModel):
    feature_count_by_geometry_type: dict[str, int]
    feature_count_by_status: dict[str, int]
    total_area_sq_m: float
    total_area_hectares: float
    total_length_m: float


class Page(BaseModel):
    total: int
    limit: int
    offset: int


class MeasurementsResponse(BaseModel):
    file_id: str
    crs: Optional[str]
    summary: Summary
    page: Page
    measurements: list[FeatureMeasurement]


class FeaturesResponse(BaseModel):
    file_id: str
    crs: Optional[str]
    page: Page
    features: list[Feature]
