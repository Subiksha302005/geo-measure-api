"""SQLite persistence (stdlib only). Swap for PostGIS/Postgres in production."""
from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS files (
    id TEXT PRIMARY KEY,
    filename TEXT NOT NULL,
    status TEXT NOT NULL,
    crs TEXT,
    feature_count INTEGER NOT NULL DEFAULT 0,
    error TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS features (
    file_id TEXT NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    feature_index INTEGER NOT NULL,
    geometry_type TEXT,
    geometry TEXT,
    is_valid INTEGER NOT NULL,
    properties TEXT NOT NULL,
    measurement TEXT NOT NULL,
    PRIMARY KEY (file_id, feature_index)
);
"""


class Repository:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        if str(db_path) != ":memory:":
            db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            with conn:  # commit / rollback
                yield conn
        finally:
            conn.close()

    # -- writes ---------------------------------------------------------
    def create_file(self, filename: str) -> str:
        file_id = uuid.uuid4().hex
        with self._conn() as c:
            c.execute(
                "INSERT INTO files (id, filename, status, created_at) VALUES (?,?,?,?)",
                (file_id, filename, "PROCESSING", datetime.now(timezone.utc).isoformat()),
            )
        return file_id

    def complete_file(self, file_id: str, crs: str, features: list[dict]) -> None:
        rows = [
            (
                file_id, f["feature_index"], f["geometry_type"],
                json.dumps(f["geometry"]), int(f["is_valid"]),
                json.dumps(f["properties"], default=str), json.dumps(f["measurement"]),
            )
            for f in features
        ]
        with self._conn() as c:
            c.executemany("INSERT INTO features VALUES (?,?,?,?,?,?,?)", rows)
            c.execute(
                "UPDATE files SET status='COMPLETED', crs=?, feature_count=? WHERE id=?",
                (crs, len(features), file_id),
            )

    def fail_file(self, file_id: str, error: str) -> None:
        with self._conn() as c:
            c.execute("UPDATE files SET status='FAILED', error=? WHERE id=?", (error, file_id))

    # -- reads ----------------------------------------------------------
    def get_file(self, file_id: str) -> Optional[dict]:
        with self._conn() as c:
            row = c.execute("SELECT * FROM files WHERE id=?", (file_id,)).fetchone()
        return dict(row) if row else None

    def list_features(
        self, file_id: str, limit: int, offset: int, geometry_type: Optional[str] = None
    ) -> tuple[int, list[dict]]:
        where, params = "file_id=?", [file_id]
        if geometry_type:
            where += " AND geometry_type=?"
            params.append(geometry_type)
        with self._conn() as c:
            total = c.execute(f"SELECT COUNT(*) FROM features WHERE {where}", params).fetchone()[0]
            rows = c.execute(
                f"SELECT * FROM features WHERE {where} ORDER BY feature_index LIMIT ? OFFSET ?",
                [*params, limit, offset],
            ).fetchall()
        return total, [self._feature(r) for r in rows]

    def summary(self, file_id: str) -> dict:
        """Aggregates computed in SQL so they cover the whole file, not one page."""
        with self._conn() as c:
            by_type = c.execute(
                "SELECT geometry_type, COUNT(*) n FROM features WHERE file_id=? GROUP BY geometry_type",
                (file_id,),
            ).fetchall()
            by_status = c.execute(
                "SELECT json_extract(measurement,'$.status') s, COUNT(*) n FROM features "
                "WHERE file_id=? GROUP BY s",
                (file_id,),
            ).fetchall()
            totals = c.execute(
                "SELECT COALESCE(SUM(json_extract(measurement,'$.area_sq_m')),0) a, "
                "COALESCE(SUM(json_extract(measurement,'$.length_m')),0) l "
                "FROM features WHERE file_id=?", (file_id,),
            ).fetchone()
        return {
            "feature_count_by_geometry_type": {(r["geometry_type"] or "None"): r["n"] for r in by_type},
            "feature_count_by_status": {r["s"]: r["n"] for r in by_status},
            "total_area_sq_m": round(totals["a"], 4),
            "total_area_hectares": round(totals["a"] / 10_000, 6),
            "total_length_m": round(totals["l"], 4),
        }

    @staticmethod
    def _feature(row: sqlite3.Row) -> dict:
        return {
            "feature_index": row["feature_index"],
            "geometry_type": row["geometry_type"],
            "geometry": json.loads(row["geometry"]),
            "is_valid": bool(row["is_valid"]),
            "properties": json.loads(row["properties"]),
            "measurement": json.loads(row["measurement"]),
        }
