from __future__ import annotations

import shutil
import tempfile
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, UploadFile, File
from fastapi.responses import JSONResponse

from ..config import Settings
from ..errors import FileTooLarge, GeoServiceError, ProcessingError, UnsupportedFileType
from ..repository import Repository
from ..schemas import FeaturesResponse, FileInfo, MeasurementsResponse
from ..services.processor import process_file

router = APIRouter(prefix="/api/files", tags=["files"])

ALLOWED_EXTENSIONS = {".zip", ".kml"}
CHUNK = 1024 * 1024


def get_repo(request: Request) -> Repository:
    return request.app.state.repo


def get_settings(request: Request) -> Settings:
    return request.app.state.settings


def _get_completed(repo: Repository, file_id: str) -> dict:
    record = repo.get_file(file_id)
    if record is None:
        raise HTTPException(404, "File not found")
    if record["status"] != "COMPLETED":
        raise HTTPException(409, f"File is {record['status']}" + (f": {record['error']}" if record["error"] else ""))
    return record


@router.post("/", response_model=FileInfo, status_code=201)
def upload_file(
    file: UploadFile = File(..., description="A .kml file or a .zip containing a Shapefile"),
    repo: Repository = Depends(get_repo),
    settings: Settings = Depends(get_settings),
):
    filename = Path(file.filename or "").name
    if Path(filename).suffix.lower() not in ALLOWED_EXTENSIONS:
        raise UnsupportedFileType("Unsupported file type. Upload a .zip (Shapefile) or .kml file.")

    with tempfile.TemporaryDirectory(prefix="upload_") as tmp:
        saved = Path(tmp) / "upload.bin"
        _save_with_limit(file, saved, settings.max_upload_bytes)

        file_id = repo.create_file(filename)
        try:
            result = process_file(
                saved, filename, settings.max_uncompressed_bytes, settings.max_features
            )
            repo.complete_file(file_id, result.crs, result.features)
        except GeoServiceError as exc:
            repo.fail_file(file_id, str(exc))
            return JSONResponse(status_code=exc.status_code, content={"detail": str(exc), "id": file_id})
        except Exception as exc:  # unexpected: record it, don't leak internals
            repo.fail_file(file_id, "Unexpected processing error")
            raise

    return repo.get_file(file_id)


def _save_with_limit(upload: UploadFile, dest: Path, limit: int) -> None:
    written = 0
    with open(dest, "wb") as out:
        while chunk := upload.file.read(CHUNK):
            written += len(chunk)
            if written > limit:
                raise FileTooLarge(f"File exceeds the {limit // (1024 * 1024)} MB upload limit")
            out.write(chunk)
    if written == 0:
        raise ProcessingError("Uploaded file is empty")


@router.get("/{file_id}/", response_model=FileInfo)
def get_file_info(file_id: str, repo: Repository = Depends(get_repo)):
    record = repo.get_file(file_id)
    if record is None:
        raise HTTPException(404, "File not found")
    return record


@router.get("/{file_id}/measurements/", response_model=MeasurementsResponse)
def get_measurements(
    file_id: str,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    geometry_type: Optional[str] = Query(None, description="e.g. Polygon, LineString, Point"),
    repo: Repository = Depends(get_repo),
):
    record = _get_completed(repo, file_id)
    total, rows = repo.list_features(file_id, limit, offset, geometry_type)
    return {
        "file_id": file_id,
        "crs": record["crs"],
        "summary": repo.summary(file_id),
        "page": {"total": total, "limit": limit, "offset": offset},
        "measurements": [
            {k: r[k] for k in ("feature_index", "geometry_type", "measurement")} for r in rows
        ],
    }


@router.get("/{file_id}/features/", response_model=FeaturesResponse)
def get_features(
    file_id: str,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    geometry_type: Optional[str] = Query(None),
    repo: Repository = Depends(get_repo),
):
    record = _get_completed(repo, file_id)
    total, rows = repo.list_features(file_id, limit, offset, geometry_type)
    return {
        "file_id": file_id,
        "crs": record["crs"],
        "page": {"total": total, "limit": limit, "offset": offset},
        "features": rows,
    }
