from __future__ import annotations

import logging

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .api.routes import router
from .config import Settings
from .errors import GeoServiceError
from .repository import Repository

logging.basicConfig(level=logging.INFO)


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings.from_env()
    app = FastAPI(
        title="Geospatial File Measurement API",
        version="1.0.0",
        description="Upload a Shapefile (.zip) or KML and get area/length measurements.",
    )
    app.state.settings = settings
    app.state.repo = Repository(settings.db_path)

    @app.exception_handler(GeoServiceError)
    async def handle_service_error(_: Request, exc: GeoServiceError):
        return JSONResponse(status_code=exc.status_code, content={"detail": str(exc)})

    @app.get("/health", tags=["meta"])
    def health():
        return {"status": "ok"}

    app.include_router(router)
    return app


app = create_app()
