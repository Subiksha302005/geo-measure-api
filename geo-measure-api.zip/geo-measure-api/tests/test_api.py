import pytest
from pyproj import Geod

from .conftest import make_shapefile_zip

from pathlib import Path

SAMPLE_KML = (Path(__file__).resolve().parent.parent / "sample_data" / "survey.kml").read_bytes()


def upload(client, name, content, mime="application/octet-stream"):
    return client.post("/api/files/", files={"file": (name, content, mime)})


def test_kml_end_to_end(client):
    r = upload(client, "survey.kml", SAMPLE_KML)
    assert r.status_code == 201
    info = r.json()
    assert info["status"] == "COMPLETED"
    assert info["crs"] == "EPSG:4326"
    assert info["feature_count"] == 4
    assert info["filename"] == "survey.kml"

    assert client.get(f"/api/files/{info['id']}/").json() == info

    m = client.get(f"/api/files/{info['id']}/measurements/").json()
    by_type = {x["geometry_type"]: x for x in m["measurements"]}
    assert by_type["Polygon"]["measurement"]["area_sq_m"] > 1e6
    assert by_type["LineString"]["measurement"]["length_m"] > 1000
    assert by_type["Point"]["measurement"]["status"] == "NOT_APPLICABLE"
    # GeometryCollection (KML MultiGeometry) is reported, not a crash
    assert by_type["GeometryCollection"]["measurement"]["status"] == "UNSUPPORTED"
    assert m["summary"]["feature_count_by_status"]["UNSUPPORTED"] == 1
    assert m["summary"]["total_area_sq_m"] == by_type["Polygon"]["measurement"]["area_sq_m"]


def test_shapefile_zip_end_to_end(client, sample_gdf):
    r = upload(client, "data.zip", make_shapefile_zip(sample_gdf))
    assert r.status_code == 201, r.text
    fid = r.json()["id"]
    assert r.json()["feature_count"] == 2

    feats = client.get(f"/api/files/{fid}/features/").json()["features"]
    assert feats[0]["properties"] == {"name": "plot1"}
    assert feats[0]["geometry"]["type"] == "Polygon"

    m = client.get(f"/api/files/{fid}/measurements/").json()["measurements"]
    true_area = abs(Geod(ellps="WGS84").geometry_area_perimeter(sample_gdf.geometry[0])[0])
    assert m[0]["measurement"]["area_sq_m"] == pytest.approx(true_area, rel=2e-3)


def test_shapefile_lines_length(client, lines_gdf):
    fid = upload(client, "roads.zip", make_shapefile_zip(lines_gdf)).json()["id"]
    m = client.get(f"/api/files/{fid}/measurements/").json()
    true_len = Geod(ellps="WGS84").geometry_length(lines_gdf.geometry[0])
    assert m["measurements"][0]["measurement"]["length_m"] == pytest.approx(true_len, rel=1e-3)
    assert m["summary"]["total_length_m"] == pytest.approx(true_len, rel=1e-3)


def test_reprojected_input_crs_gives_same_area(client, sample_gdf):
    a = upload(client, "a.zip", make_shapefile_zip(sample_gdf)).json()["id"]
    b = upload(client, "b.zip", make_shapefile_zip(sample_gdf.to_crs(32644))).json()
    assert b["crs"] == "EPSG:32644"
    area = lambda fid: client.get(f"/api/files/{fid}/measurements/").json()["measurements"][0]["measurement"]["area_sq_m"]
    assert area(b["id"]) == pytest.approx(area(a), rel=1e-4)


def test_pagination_and_filter(client):
    fid = upload(client, "survey.kml", SAMPLE_KML).json()["id"]
    page = client.get(f"/api/files/{fid}/measurements/?limit=2&offset=1").json()
    assert page["page"] == {"total": 4, "limit": 2, "offset": 1}
    assert [x["feature_index"] for x in page["measurements"]] == [1, 2]
    only = client.get(f"/api/files/{fid}/measurements/?geometry_type=Polygon").json()
    assert only["page"]["total"] == 1


def test_rejects_wrong_extension(client):
    assert upload(client, "notes.txt", b"hello").status_code == 415


def test_rejects_garbage_kml_and_records_failure(client):
    r = upload(client, "bad.kml", b"this is not xml")
    assert r.status_code == 422
    fid = r.json()["id"]
    info = client.get(f"/api/files/{fid}/").json()
    assert info["status"] == "FAILED" and info["error"]
    assert client.get(f"/api/files/{fid}/measurements/").status_code == 409


def test_rejects_zip_without_shapefile(client):
    import io, zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("readme.txt", "nothing here")
    assert upload(client, "x.zip", buf.getvalue()).status_code == 422


def test_rejects_shapefile_without_crs(client, sample_gdf):
    r = upload(client, "nocrs.zip", make_shapefile_zip(sample_gdf, drop_prj=True))
    assert r.status_code == 422 and "CRS" in r.json()["detail"]


def test_rejects_not_a_zip_and_empty(client):
    assert upload(client, "x.zip", b"not a zip").status_code == 422
    assert upload(client, "e.kml", b"").status_code == 422


def test_zip_slip_names_are_flattened(client, sample_gdf):
    import io, zipfile
    data = make_shapefile_zip(sample_gdf)
    src = zipfile.ZipFile(io.BytesIO(data))
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for n in src.namelist():
            zf.writestr(f"../../evil/{n}", src.read(n))
    assert upload(client, "evil.zip", buf.getvalue()).status_code == 201


def test_unknown_id_404(client):
    assert client.get("/api/files/nope/").status_code == 404
    assert client.get("/api/files/nope/measurements/").status_code == 404


def test_upload_size_limit(client):
    assert upload(client, "big.kml", b"x" * (6 * 1024 * 1024)).status_code == 413
