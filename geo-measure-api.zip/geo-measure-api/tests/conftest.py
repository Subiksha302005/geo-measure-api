import io
import shutil
import tempfile
import zipfile
from pathlib import Path

import geopandas as gpd
import pytest
from fastapi.testclient import TestClient
from shapely.geometry import LineString, Point, Polygon

from app.config import Settings
from app.main import create_app


@pytest.fixture()
def client(tmp_path):
    settings = Settings(
        db_path=tmp_path / "test.db",
        max_upload_bytes=5 * 1024 * 1024,
        max_uncompressed_bytes=20 * 1024 * 1024,
        max_features=1000,
    )
    return TestClient(create_app(settings))


def make_shapefile_zip(gdf: gpd.GeoDataFrame, drop_prj: bool = False) -> bytes:
    with tempfile.TemporaryDirectory() as tmp:
        gdf.to_file(Path(tmp) / "data.shp")
        if drop_prj:
            (Path(tmp) / "data.prj").unlink()
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            for f in Path(tmp).iterdir():
                zf.write(f, f.name)
        return buf.getvalue()


@pytest.fixture()
def sample_gdf():
    """Polygon layer (a Shapefile can only hold one geometry type)."""
    return gpd.GeoDataFrame(
        {"name": ["plot1", "plot2"]},
        geometry=[
            Polygon([(78.68, 10.80), (78.69, 10.80), (78.69, 10.81), (78.68, 10.81)]),
            Polygon([(78.70, 10.80), (78.71, 10.80), (78.71, 10.82), (78.70, 10.82)]),
        ],
        crs="EPSG:4326",
    )


@pytest.fixture()
def lines_gdf():
    return gpd.GeoDataFrame(
        {"name": ["road"]},
        geometry=[LineString([(78.68, 10.80), (78.70, 10.82)])],
        crs="EPSG:4326",
    )
