"""Unit tests for measurement + CRS logic, validated against geodesic truth."""
import pytest
from pyproj import CRS, Geod
from shapely.geometry import GeometryCollection, LineString, MultiPolygon, Point, Polygon

from app.services.crs import utm_epsg_for
from app.services.measurements import (
    INVALID, MEASURED, NOT_APPLICABLE, UNSUPPORTED, measure_geometry,
)

WGS84 = CRS.from_epsg(4326)
GEOD = Geod(ellps="WGS84")


@pytest.mark.parametrize("lon,lat,epsg", [
    (78.68, 10.8, 32644),    # India, northern hemisphere
    (-0.1, 51.5, 32630),     # London
    (151.2, -33.9, 32756),   # Sydney, southern hemisphere
    (0, 89, 32661),          # polar cap -> UPS north
])
def test_utm_zone_selection(lon, lat, epsg):
    assert utm_epsg_for(lon, lat) == epsg


@pytest.mark.parametrize("origin", [(78.68, 10.8), (-0.1, 51.5), (151.2, -33.9), (10, 60)])
def test_polygon_area_matches_geodesic(origin):
    x, y = origin
    poly = Polygon([(x, y), (x + 0.02, y), (x + 0.02, y + 0.02), (x, y + 0.02)])
    result = measure_geometry(poly, WGS84)
    true_area, _ = GEOD.geometry_area_perimeter(poly)
    assert result.status == MEASURED
    assert result.area_sq_m == pytest.approx(abs(true_area), rel=2e-3)
    assert result.area_hectares == pytest.approx(result.area_sq_m / 10_000, rel=1e-6)
    # Naive degree-based area would be ~1e-4 "sq degrees": prove we're not using it.
    assert result.area_sq_m > 1e5


def test_line_length_matches_geodesic():
    line = LineString([(78.68, 10.80), (78.70, 10.82), (78.72, 10.82)])
    result = measure_geometry(line, WGS84)
    assert result.length_m == pytest.approx(GEOD.geometry_length(line), rel=1e-3)
    assert result.projected_crs == "EPSG:32644"


def test_multipolygon_and_z_coordinates():
    p1 = Polygon([(78, 10, 5), (78.01, 10, 5), (78.01, 10.01, 5)])
    p2 = Polygon([(78.1, 10), (78.11, 10), (78.11, 10.01)])
    result = measure_geometry(MultiPolygon([p1, p2]), WGS84)
    assert result.status == MEASURED and result.area_sq_m > 0


def test_projected_crs_measured_directly():
    utm = CRS.from_epsg(32644)
    sq = Polygon([(0, 0), (100, 0), (100, 100), (0, 100)])
    result = measure_geometry(sq, utm)
    assert result.area_sq_m == 10_000 and result.perimeter_m == 400


def test_projected_crs_in_feet_is_converted():
    ft = CRS.from_epsg(2263)  # NY Long Island, US survey feet
    sq = Polygon([(0, 0), (100, 0), (100, 100), (0, 100)])
    result = measure_geometry(sq, ft)
    assert result.area_sq_m == pytest.approx(10_000 * 0.3048006096**2, rel=1e-4)


def test_graceful_handling_of_odd_geometries():
    assert measure_geometry(Point(1, 1), WGS84).status == NOT_APPLICABLE
    assert measure_geometry(None, WGS84).status == INVALID
    assert measure_geometry(Polygon(), WGS84).status == INVALID
    gc = GeometryCollection([Point(1, 1), LineString([(0, 0), (1, 1)])])
    assert measure_geometry(gc, WGS84).status == UNSUPPORTED
